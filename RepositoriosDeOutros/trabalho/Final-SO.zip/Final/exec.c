/* pipe() */
#define _GNU_SOURCE             /* See feature_test_macros(7) */

/* pipe(), fork(), dup2(), close(), execlp(), read(), write() precisam das seguintes libs */
#include <unistd.h>

/* pipe() stat() precisam das seguintes libs */
#include <fcntl.h>              /* Obtain O_* constant definitions */
#include <unistd.h>

/* wait() stat() precisam das seguintes libs */
#include <sys/types.h>
#include <sys/wait.h>

/* stat() precisa das seguintes libs */
#include <sys/stat.h>

#include <string.h>
#include <stdlib.h>
#include <stdio.h>

char *calculaSha1Sum(char *ficheiro){
	int fd1[2], fd2[2], nBytesLidos, status;
	char buff[512];
	char *str;
  pipe(fd1);
  if (fork()==0){
    pipe(fd2);
    if (fork()==0){
      dup2(fd2[1],1);
      close(fd2[0]);
      close(fd2[1]);
      execlp("sha1sum","sha1sum",ficheiro,NULL);
      _exit(0);
    }
    else{
      wait(&status);
      dup2(fd2[0],0);
      dup2(fd1[1],1);
      close(fd2[0]);
      close(fd2[1]);
      close(fd1[0]);
      close(fd1[1]);
      execlp("awk","awk","{print $1}",NULL);
    }
    _exit(0);
  }
  else{
    wait(&status);
    dup2(fd1[0],0);
    close(fd1[1]);
    nBytesLidos = read(fd1[0], buff, 512);
    str = malloc(sizeof(char) * (nBytesLidos + 1));
    if(str){
      strcpy(str, strtok(buff, "\r\n"));
    }
    close(fd1[0]);
  }
  return str;
}

char *getFileName(char *file){
  char *str, *aux , *res;
  int i, status;
  int fd[2], nBytesLidos;
  char buff[128];
  pipe(fd);
  if (fork()==0){
    dup2(fd[1],1);
    close(fd[0]);
    close(fd[1]);
    execlp("readlink","readlink","-f",file, NULL);
    _exit(0);
  }
  else{
    wait(&status);
    close(fd[1]);
    nBytesLidos = read(fd[0], buff, 128);
    aux = strtok(buff, "\r\n");
    str = malloc(sizeof(char) * nBytesLidos);
    res = malloc(sizeof(char) * nBytesLidos);
    if(str)
      strcpy(str, aux);
    close(fd[0]);
    for (i = strlen(str);  i>0 && str[i]!='/'; i--); 
    strcpy(res,&str[i+1]);
  }
  return res;
}

char *getFileAbsolutePath(char *file){
  char *str, *aux , *res;
  int i, j, status;
  int fd[2], nBytesLidos;
  char buff[128];
  pipe(fd);
  if (fork()==0)  {
    dup2(fd[1],1);
    close(fd[0]);
    close(fd[1]);
    execlp("readlink","readlink","-f",file, NULL);
    _exit(0);
  }
  else{
    wait(&status);
    close(fd[1]);
    nBytesLidos = read(fd[0], buff, 128);
    aux = strtok(buff, "\r\n");
    str = malloc(sizeof(char) * nBytesLidos);
    res = malloc(sizeof(char) * nBytesLidos);
    if(str)
      strcpy(str, aux);
    close(fd[0]);
    for (i = strlen(str);  i>0 && str[i]!='/'; i--);
    for (j = 0; j < i; j++)
      res[j]=str[j];
    res[j]='\0';
  }
  return res;
}

char fromBinToOctal(char ch1,char ch2, char ch3){
  if(ch1=='1'){
    if (ch2=='1'){
      if (ch3=='1')
        return '7';
      else
        return '6';
    }
    else{
      if (ch3=='1')
        return '5';
      else
        return '4';
    }
  }
  else{
    if (ch2=='1'){
      if (ch3=='1')
        return '3';
      else
        return '2';
    }
    else{
      if (ch3=='1')
        return '1';
      else
        return '0';
    }
  } 
}

char *getPermitions(char *ficheiro){
  int i=0;
  int p[2];
  int pp[2];
  char bin[10];
  char *oct;
  char buf;
  oct = malloc(sizeof(char) * 4);
  pipe(p);
  if (fork()==0){
    pipe(pp);
    if (fork()==0){
      dup2(pp[1],1);
      close(pp[0]);
      close(pp[1]);
      execlp("ls","ls","-l",ficheiro,NULL);
    }
    else{
      dup2(pp[0],0);
      dup2(p[1],1);
      close(pp[0]);
      close(pp[1]);
      close(p[0]);
      close(p[1]);
      execlp("awk","awk","{print $1}",NULL);
    } 
  }
  else{
    dup2(p[0],0);
    close(p[0]);
    close(p[1]);
    while(read(0,&buf,1)!=0){
      if (buf=='-')
        bin[i]=	'0';
      else
        bin[i]='1';
      i++;
    }
    oct[0]=bin[0];
    oct[1]=fromBinToOctal(bin[1],bin[2],bin[3]);
    oct[2]=fromBinToOctal(bin[4],bin[5],bin[6]);
    oct[3]=fromBinToOctal(bin[7],bin[8],bin[9]);
  }
  return oct;
}

void changePermission(char *dirname){
  int status;
  if (fork()==0){
    execlp("chmod","chmod","777",dirname, NULL);
    _exit(0);
  }
  else{
    wait(&status);
  }
}

void makeDirectory(char *dirname){
  int status;
  if (fork()==0){
    execlp("mkdir","mkdir","-p",dirname, NULL);
    _exit(0);
  }
  else{
    wait(&status);
  }
}

int makeLink(char *ficheiro, char *link){
	int status;
	if (fork()==0){
		execlp("ln","ln","-s",ficheiro,link,NULL);
		_exit(0);
	}
	else{
		wait(&status);
	}
	return 0;	
}

int removeLink(char *link){
	int status;
	if (fork()==0){
		execlp("unlink","unlink",link,NULL);
		_exit(0);
	}
	else{
		wait(&status);
	}
	return 0;	
}

int makeZip(char *ficheiro){
  int status;
  if(fork()==0){
    execlp("gzip","gzip",ficheiro,NULL);
    _exit(0);
  }
  else {
    wait(&status);
  }
  return 0;
}

int makeUnzip(char *ficheiro){
  int status;
  if(fork()==0){
    execlp("gzip","gzip","-d","--name",ficheiro,NULL);
    _exit(0);
  }
  else {
    wait(&status);
  }
  return 0;
}

int copyFile(char *ficheiroOri, char *ficheiroDest){
  char str[512];
  int status;
  sprintf(str, "%s.gz",ficheiroOri);
  if(fork()==0){
    execlp("cp","cp","-f",ficheiroOri,ficheiroDest,NULL);
    _exit(0);
  }
  else {
    wait(&status);
  }
  return 0;
}

int moveZip(char *ficheiro, char *zipFile){
  char str[512];
  int status;
  sprintf(str, "%s.gz",ficheiro);
  if(fork()==0){
    execlp("mv","mv","-f",str,zipFile,NULL);
    _exit(0);
  }
  else {
    wait(&status);
  }
  return 0;
}

int deleteFile(char *ficheiro){
  int status;
  if(fork()==0){
    execlp("rm","rm","-f",ficheiro,NULL);
    _exit(0);
  }
  else {
    wait(&status);
  }
  return 0;
}

