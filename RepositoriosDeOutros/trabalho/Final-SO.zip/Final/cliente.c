/*comando Kill - compiler warning: implicit declaration of function ‘kill’ */
#define _POSIX_SOURCE

/* open() wait() stat() precisam das seguintes libs */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/* close(), write(), read() precisam das seguintes libs */
#include <unistd.h>

/* wait() precisa das seguintes libs */
#include <sys/wait.h>

/* opendir() precisa das seguintes libs */
#include <dirent.h>

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "enviaFicheiros.h"
#include "exec.h"

#define tamCMD 512
#define sobusrv "/tmp/sobusrv" /*Named Pipe do servidor*/

int fileExists = 0;

void sigHandler(int s){
  switch (s){
    case SIGUSR1:
      /*printf("Enviado/Recebido/Apagado.\n");*/
    break;
    case SIGUSR2:
      /*printf("Não Enviado/Recebido/Apagado.\n");*/
      kill(getpid(), SIGQUIT);
    break;
    case SIGCONT:
      /*printf("Sinal CONT Recebido.\n");*/
    break;
    case SIGINT:
      /*printf("Sinal INT Recebido.\n");*/
      kill(getpid(), SIGQUIT);
    break;
    case SIGPIPE:
      /*printf("Sinal SIGPIPE Recebido.\n");*/
    break;
    case SIGHUP:
      /*printf("Sinal SIGHUP Recebido.\n");*/
      fileExists = 1;
    break;    
    default:
    break;  
  }
}

void criaPaths(){
  char backupPathData[512];
  char backupPathMetadata[512];
  char backupPath[512];
  DIR* backupDir;

  sprintf(backupPath, "%s/.Backup", getenv("HOME"));
  backupDir = opendir(backupPath);
  if (backupDir){
    closedir(backupDir);
  }
  else{
    makeDirectory(backupPath);
    changePermission(backupPath);
  }
  
  sprintf(backupPathData, "%s/.Backup/data", getenv("HOME"));
  backupDir = opendir(backupPathData);
  if (backupDir){
    closedir(backupDir);
  }
  else{
    makeDirectory(backupPathData);
    changePermission(backupPathData);
  }
  
  sprintf(backupPathMetadata, "%s/.Backup/metadata", getenv("HOME"));
  backupDir = opendir(backupPathMetadata);
  if (backupDir){
    closedir(backupDir);
  }
  else{
    makeDirectory(backupPathMetadata);
    changePermission(backupPathMetadata);
  }
}

int enviaComando(char* FIFO, char tipo, char *ficheiro, char *path, char *sha1, char *permissoes, char *userPath){
  int fd, i, status;
  char comando[tamCMD];

  i = sprintf(comando, "%c %s %s %s %s %s", tipo, ficheiro, path, sha1, permissoes, userPath);

  if(fork()==0){
    fd = open(FIFO, O_WRONLY);
    if(fd > 0){
      write(fd, comando, i);
    }
    else{
      printf("erro open FIFO.\n");
    }
    close(fd);
    _exit(0);
  }
  else {
    wait(&status);
  }
  return 0;
}

int backupCmd(char* fifoc, char *fifod, char *filename, char *userPath){
  char *sha1, *path, *permissoes, *ficheiro;
  struct stat statbuffer;
  signal(SIGUSR1,sigHandler);
  signal(SIGPIPE,sigHandler);
  signal(SIGHUP,sigHandler);
  stat(filename, &statbuffer);
  if(S_ISDIR(statbuffer.st_mode)) /* verifica se é uma directoria. ver man stat() */
    return 1;
  sha1 = calculaSha1Sum(filename);
  path = getFileAbsolutePath(filename);
  permissoes = getPermitions(filename);
  ficheiro = getFileName(filename);
  enviaComando(fifoc, 'B', ficheiro, path, sha1, permissoes, userPath);
  pause();
  if (fileExists){
    fileExists = 0;
    printf("%s: copiado.\n", filename);
    return 1;
  }
  sleep(1); /*para dar tempo ao servidor de abrir o FIFO de dados*/
  iniciaTx(fifod, filename);
  pause();
  printf("%s: copiado.\n", filename);
  return 0;
}

int restoreCmd(char* fifoc, char *fifod, char *filename, char *userPath){
  signal(SIGUSR1,sigHandler);
  signal(SIGUSR2,sigHandler);
  enviaComando(fifoc, 'R', filename, NULL,NULL,NULL,NULL);
  /*pause();*/
  iniciaRx(fifod, filename);
  printf("%s: Recuperado.\n", filename);
  return 0;
}

int deleteCmd(char* fifoc, char *fifod, char *filename, char *userPath){
  signal(SIGUSR1,sigHandler);
  signal(SIGUSR2,sigHandler);
  enviaComando(fifoc, 'D', filename, NULL,NULL,NULL,NULL);
  pause();
  printf("%s: Removido.\n", filename);
  return 0;
}
/*
int gcCmd(char* fifoc){
  signal(SIGUSR1,sigHandler);
  enviaComando(fifoc, 'G', NULL, NULL,NULL,NULL,NULL);
  pause();
  return 0;
}
*/
int IniciaSessao(char* FIFO){
  int pid, fd, i, status; /* erro; */
  char comando[tamCMD], *userPath;

  signal(SIGCONT,sigHandler);
  signal(SIGINT,sigHandler);
  pid = getpid();
  userPath=getenv("HOME");
  i = sprintf(comando, "%d %s", pid, userPath);
  
  if(fork()==0){
    fd = open(FIFO, O_WRONLY);
    if(fd > 0){
      write(fd, comando, i); /*comando[tamCMD]*/
      close(fd);
      _exit(0);
    }
    else{
      printf("erro open FIFO.\n");
    }
  }
  else {
    pause();
    wait(&status);
    /*printf("Comando \"%s\" com tamanho %d foi enviado com sucesso!\n", comando, i);*/
  }
  return 0;
}

int comandoSessao(char *FIFO, char *userPath, int pid){
  int fd, tam, erro;
  char comando[tamCMD];
  erro = 0;
  /*printf("FIFO: %s, %s, %d\n", FIFO, userPath, pid);*/
  fd = open(FIFO, O_WRONLY);
  if(fd > 0){
    tam = sprintf(comando, "%d %s", pid, userPath);
    write(fd, comando, tam);
  }
  else{
    erro = 1; /*erro ao abrir FIFO*/
  }
  close(fd);
  return erro;
}

int main(int argc, char *argv[]){
  int erro, pid, i;
  char *userPath, fifoc[256], fifod[256];

  signal(SIGCONT,sigHandler);
  signal(SIGINT,sigHandler);

  erro = 0;
  criaPaths();
  
  if (argc<=2){
      printf("Modo de uso:\n");
      printf("Utilização sobucli [OPÇÃO] [FICHEIRO]...\n");
      printf("   backup  - Salvaguarda um ou mais ficheiros.\n");
      printf("   restore - Recupera um ou mais ficheiros.\n");
      printf("   delete  - Apaga um ou mais ficheiros.\n");
      printf("   gc      - Não implementado\n");
  }
  else{
  
    pid=getpid();
    userPath = getenv("HOME");
    sprintf(fifoc, "%s/.Backup/%dC", userPath, pid);
    sprintf(fifod, "%s/.Backup/%dD", userPath, pid);

    /*comando backup */
  	if(strcmp(argv[1], "backup")==0){
      erro = comandoSessao(sobusrv, getenv("HOME"), getpid());
      if (erro == 0){
        pause();/*aguarda sinal para saber se o servidor leu o comando*/
  	    for (i=2; i<argc; i++){
          backupCmd(fifoc, fifod, argv[i], userPath);
        }
        enviaComando(fifoc, 'S', NULL,NULL,NULL,NULL,NULL);
      }
      else {
        printf("Erro ao iniciar Sessao: %d\n", erro);
      }
  	}
  	
    /*comando restore*/
  	else if (strcmp(argv[1], "restore")==0){
  	  erro = comandoSessao(sobusrv, getenv("HOME"), getpid());
      if (erro == 0){
        pause();
        for (i=2; i<argc; i++){
          restoreCmd(fifoc, fifod, argv[i], userPath);
        }
        enviaComando(fifoc, 'S', NULL,NULL,NULL,NULL,NULL);
      }
      else {
        printf("Erro ao iniciar Sessao: %d\n", erro);
      }
    }
    
    /*comando delete*/
    else if (strcmp(argv[1], "delete")==0){
      erro = comandoSessao(sobusrv, getenv("HOME"), getpid());
      if (erro == 0){
        pause();
        for (i=2; i<argc; i++){
          deleteCmd(fifoc, fifod, argv[i], userPath);
        }
        enviaComando(fifoc, 'S', NULL,NULL,NULL,NULL,NULL);
      }
      else {
        printf("Erro ao iniciar Sessao: %d\n", erro);
      }
    }

    /*comando gc*/    
/*
    else if (strcmp(argv[1], "gc")==0){
      erro = comandoSessao(sobusrv, getenv("HOME"), getpid());
      if (erro == 0){
        pause();
        printf("vou fazer gc\n\n\n\n");
        for (i=2; i<argc; i++){
          deleteCmd(fifoc, fifod, argv[i], userPath);
        }
        enviaComando(fifoc, 'S', NULL,NULL,NULL,NULL,NULL);
      }
      else {
        printf("Erro ao iniciar Sessao: %d\n", erro);
      }
    }
*/
  }
  return 0;
}

