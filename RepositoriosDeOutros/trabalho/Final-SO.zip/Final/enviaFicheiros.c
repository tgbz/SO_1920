/*comando Kill - compiler warning: implicit declaration of function ‘kill’ */
#define _POSIX_SOURCE

/* open() precisa das seguintes libs */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/* mkfifo() precisa das seguintes libs */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h> /* Definicao das constantes AT_* */
#include <sys/stat.h>

/* close(), write(), read() precisam das seguintes libs */
#include <unistd.h>

/* funcao kill() precisa das seguintes libs*/
#include <sys/types.h>
#include <signal.h>

#include <stdio.h>
#include <stdlib.h>

#define tamBuffer 4096

int iniciaTx(char* FIFO, char* ficheiro){ /*envia ficheiro pelo fifo*/
  int fdFicheiro, fdFIFO, tamMax, erro;
  char buffer[tamBuffer];
  erro = 0;
  if ((fdFicheiro = open(ficheiro, O_RDONLY)) > 0){
    if ((fdFIFO = open(FIFO, O_WRONLY)) > 0){
      while ((tamMax=read(fdFicheiro, buffer, tamBuffer)) > 0){
        write(fdFIFO, buffer, tamMax);
      }
      close(fdFIFO);	
      close(fdFicheiro);
    }
    else {
      erro = 2; /*erro no open do FIFO*/
    }
  }
  else {
    erro = 1; /*erro no open do FICHEIRO*/
  }
  return erro;
}

int iniciaRx(char* FIFO, char* ficheiro){/*recebe ficheiro pelo FIFO */
  int fdFicheiro, fdFIFO, tamMax, erro;
  char buffer[tamBuffer];
  erro = 0;
  if (mkfifo(FIFO, 0666) == 0){ /* permissoes do fifo - R-- -W- -W- */
    if((fdFicheiro = open(ficheiro, O_WRONLY | O_CREAT, 0644))>0){ /*permissoes do ficheiro iguais user */
      if((fdFIFO = open(FIFO, O_RDONLY))>0){ /*stdin*/
        while ((tamMax=read(fdFIFO, buffer, tamBuffer)) > 0){
          write(fdFicheiro, buffer, tamMax);
        }
        close(fdFicheiro);
        close(fdFIFO);
        unlink(FIFO);
      }
      else {
        erro = 3; /*erro no open do FIFO */
      }
    }
    else {
      erro = 2; /*erro no open do Ficheiro */
    }
  }
  else {
    erro = 1; /*erro no make do fifo */
  }
  return erro;
}

