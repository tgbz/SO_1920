# SOBUSRV / SOBUCLI
Trabalho Pratico da disciplina de Sistemas Operativos - Universidade do Minho 2016
Sistema de Backup Local Cliente Servidor

#criar tudo
make all

#criar cliente
make sobucli

#criar servidor
make sobusrv

#instalar - necessário sudo
make install
