/* pipe() */
#define _GNU_SOURCE             /* See feature_test_macros(7) */

/* pipe(), fork(), dup2(), close(), execlp(), read(), write() precisam das seguintes libs */
#include <unistd.h>

/* pipe() precisa das seguintes libs */
#include <fcntl.h>              /* Obtain O_* constant definitions */
#include <unistd.h>

/* wait() precisa das seguintes libs */
#include <sys/types.h>
#include <sys/wait.h>

#include <string.h>
#include <stdlib.h>

#ifndef _exec
#define _exec

char *calculaSha1Sum(char *ficheiro);

char *getuser(int pid);

char *getFileName(char *file);

char *getFileAbsolutePath(char *file);

char fromBinToOctal(char ch1,char ch2, char ch3);

char *getPermitions(char *ficheiro);

void changePermission(char *dirname);

void makeDirectory(char *dirname);

int makeLink(char *arg1, char *arg2);

int removeLink(char *link);

int makeZip(char *ficheiro);

int makeUnzip(char *ficheiro);

int copyFile(char *ficheiroOri, char *ficheiroDest);

int moveZip(char *ficheiro, char *zipFile);

int renameFile(char *origem, char *destino);

int deleteFile(char *ficheiro);

#endif
