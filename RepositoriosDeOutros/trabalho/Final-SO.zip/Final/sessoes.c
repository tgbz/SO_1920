/*kill() - compiler warning: implicit declaration of function ‘kill’ */
#ifndef _POSIX_SOURCE
#define _POSIX_SOURCE
#endif

/*readlink() - compiler warning: implicit declaration of function ‘readlink’ */
#define _BSD_SOURCE || _XOPEN_SOURCE >= 500 || _XOPEN_SOURCE && _XOPEN_SOURCE_EXTENDED || _POSIX_C_SOURCE >= 200112L

/* funcao kill() precisa das seguintes libs*/
#include <sys/types.h>
#include <signal.h>

/* open() precisa das seguintes libs */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/* close(), write(), read(), readlink() precisam das seguintes libs */
#include <unistd.h>

/* readlink() precisa das seguintes libs */
#include <fcntl.h>

#include "enviaFicheiros.h"
#include "exec.h"

#define tamCMD 1024

typedef struct comandoFicheiro{
  char tipo;
  char ficheiro[256];
  char permissoes[10];
  char path[256];
  char sha1sum[64];
  char userPath[256];
} comandoF;

int leComando(char *buffer, comandoF *cmd){
  sscanf(buffer, "%c %s %s %s %s %s", &cmd->tipo, cmd->ficheiro, cmd->path, cmd->sha1sum, cmd->permissoes, cmd->userPath);
  return 0;
}

void iniciaSessao(int pid, char* userPath){
  int fd, loopT, i;
  char servidorFIFODados[512];
  char servidorFIFOComando[512];
  char servidorFicheiro[512];
  char servidorFicheirosPath[512];
  char srvFile[512];
  char zipFile[512];
  char linkFile[512];
  char buffer[tamCMD];

  comandoF cmd;
  
  sprintf(servidorFIFODados, "%s/.Backup/%dD", userPath, pid);
  sprintf(servidorFIFOComando, "%s/.Backup/%dC", userPath, pid);
  sprintf(servidorFicheirosPath, "%s/.Backup/", userPath);
  
  printf("data: %s\n", servidorFIFODados);
  printf("cmd_: %s\n", servidorFIFOComando);
  
  loopT = 1;
  
  if ((mkfifo(servidorFIFOComando, 0666)) == 0){
    printf("arrancou servidor secundário com id: %d\n", getpid());
    kill(pid,SIGCONT);
  }
  else {
    printf("Erro de FIFO");
    loopT = 0;
    kill(pid,SIGINT);
  }
  
  while(loopT){
    fd = open(servidorFIFOComando, O_RDONLY);
    for (i=0; i<tamCMD; i++) buffer[i] = '\0';
    while (read(fd, buffer, tamCMD) > 0) {
      leComando(buffer, &cmd);
    }
    close(fd);

    if (cmd.tipo == 'B'){
      sprintf(srvFile, "%s/.Backup/%s", userPath, cmd.ficheiro);
      sprintf(zipFile, "%s/.Backup/data/%s.gz", userPath, cmd.sha1sum);
      sprintf(linkFile, "%s/.Backup/metadata/%s", userPath, cmd.ficheiro);
      if (access(zipFile, F_OK) != -1){
        makeLink(zipFile, linkFile);
        kill(pid,SIGHUP);
      }
      else{
        kill(pid,SIGPIPE);
        iniciaRx(servidorFIFODados, srvFile);
        makeZip(srvFile);
        moveZip(srvFile, zipFile);
        makeLink(zipFile, linkFile);
      }
      kill(pid,SIGUSR1);
      printf("Comando B\n");
    }

    else if(cmd.tipo == 'R'){
      sprintf(servidorFicheiro, "%smetadata/%s", servidorFicheirosPath, cmd.ficheiro);
      if (access(servidorFicheiro, F_OK) != -1){ /*verifica se o link existe */
        readlink(servidorFicheiro, linkFile, 511); /* le caminho do link */
        sprintf(zipFile, "%s/.Backup/%s", userPath, getFileName(servidorFicheiro));
        sprintf(srvFile, "%s/.Backup/%s", userPath, cmd.ficheiro);
        if(access(linkFile, F_OK) != -1){ /*verifica se o ficheiro existe */
          copyFile(linkFile, zipFile);
          makeUnzip(zipFile);
          kill(pid,SIGUSR1);
          sleep(1); /* o cliente deve iniciar o RX em primeiro lugar para evitar deadlocks */
          iniciaTx(servidorFIFODados, srvFile);
          deleteFile(srvFile);
          printf("Comando R\n");
        }
        else{
          loopT=0;
          kill(pid,SIGUSR2);
          printf("######## Sessao Fechada ########\n");
        }
      }
      else{
        loopT=0;
        kill(pid,SIGUSR2);
        printf("######## Sessao Fechada ########\n");
      }
    }

    else if(cmd.tipo == 'D'){
      sprintf(servidorFicheiro, "%smetadata/%s", servidorFicheirosPath, cmd.ficheiro);
      printf("file: %s\n", servidorFicheiro);
      if (access(servidorFicheiro, F_OK) != -1){ /*verifica se o link existe */
        removeLink(servidorFicheiro);
        kill(pid,SIGUSR1);
      }
      else{
        loopT=0;
        kill(pid,SIGUSR2);
        printf("######## Sessao Fechada ########\n");
      }
    }

    else if(cmd.tipo == 'S'){
      loopT=0;
      kill(pid,SIGUSR2);
      printf("######## Sessao Fechada ########\n");
    }
    
    else {
      loopT=0;
      kill(pid,SIGUSR2);
      printf("######## Sessao Fechada ########\n");
    }
     
  }
  unlink(servidorFIFOComando);
}
