/*comando Kill - compiler warning: implicit declaration of function ‘kill’ */
#define _POSIX_SOURCE

/* open() wait() stat() precisam das seguintes libs */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/* funcao kill() precisa das seguintes libs*/
#include <sys/types.h>
#include <signal.h>

/* wait() precisa das seguintes libs */
#include <sys/wait.h>

#include <stdio.h>

#include "enviaFicheiros.h"
#include "exec.h"
#include "sessoes.h"

#define tamCMD 1024
#define servidorFIFOPATH "/tmp/sobusrv" /*Named Pipe do servidor*/

int maxCli = 0;

typedef struct comandoSessao{
  int pid;
  char userPath[256];
} cmdSessao;

void sigHandler(int s){
  switch (s){
    case SIGINT:
      unlink(servidorFIFOPATH);
      kill(getpid(),SIGQUIT);
    break;
    case SIGCHLD:
      wait(NULL);
      maxCli--;
    break;
    
    default:
    break;  
  }
}

/****************************************************/

void lePedido(char *comando, cmdSessao *cmd){
  sscanf(comando, "%d %s", &cmd->pid, cmd->userPath);
}

/****************************************************/
  
int main(){	
  int fd, loopT, i;
  char buffer[tamCMD];
  cmdSessao cmd;
  
  signal(SIGINT,sigHandler);
  signal(SIGCHLD, sigHandler);
  
  loopT = 1;

  if ((mkfifo(servidorFIFOPATH, 0666)) == 0) {
     printf("arrancou servidor com id: %d\n", getpid());
  }
  else {
    printf("Erro de FIFO");
    loopT = 0;
  }
  
  while(loopT){
    for (i=0; i<tamCMD; i++) buffer[i] = '\0'; /*clear buffer*/
    fd = open(servidorFIFOPATH, O_RDONLY);
    while (read(fd, buffer, tamCMD) > 0) {
      lePedido(buffer, &cmd);
    }
    close(fd);
    if (maxCli < 5){
      maxCli++;
      if(fork()==0){
        iniciaSessao(cmd.pid, cmd.userPath);
        _exit(0);
      }
    }
    else{
      kill(cmd.pid, SIGINT);
    }
  }
  unlink(servidorFIFOPATH);
  return 0;
}

