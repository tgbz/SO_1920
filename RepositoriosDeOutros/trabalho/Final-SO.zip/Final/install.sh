#!/bin/sh

cp ./sobucli /usr/local/bin/
cp ./sobusrv /usr/local/bin/

#cp ./initScript/sobusrv /etc/init.d
#echo 0 > /var/run/sobusrv.pid
#chown user:user /var/run/sobusrv.pid
#chmod 777 /var/run/sobusrv.pid
#chmod +x /etc/init.d/sobusrv

