/*kill() - compiler warning: implicit declaration of function ‘kill’ */
#ifndef _POSIX_SOURCE
#define _POSIX_SOURCE
#endif

/* funcao kill() precisa das seguintes libs*/
#include <sys/types.h>
#include <signal.h>

/* open() precisa das seguintes libs */
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

/* close(), write(), read(), readlink() precisam das seguintes libs */
#include <unistd.h>

/* readlink() precisa das seguintes libs */
#include <fcntl.h>

#include "enviaFicheiros.h"
#include "exec.h"

#define tamCMD 1024

#ifndef _SESSOES
#define _SESSOES

/* Inicia uma nova sessão para um cliente   */
/* Recebe Pid do cliente e Path para a Home */
void iniciaSessao(int pid, char* userPath);

#endif
